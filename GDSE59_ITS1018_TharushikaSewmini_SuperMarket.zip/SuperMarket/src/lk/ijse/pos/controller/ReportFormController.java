package lk.ijse.pos.controller;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class ReportFormController {
    public TableView tblMostItems;
    public TableColumn colMostCode;
    public TableColumn colMostDescription;
    public TableColumn colMostPackSize;
    public TableColumn colMostQtyOnHand;
    public TableColumn colMostUnitPrice;
    public TableView tblLeastItems;
    public TableColumn colLeastCode;
    public TableColumn colLeastDescription;
    public TableColumn colLeastPackSize;
    public TableColumn colLeastQtyOnHand;
    public TableColumn colLeastUnitPrice;
}
